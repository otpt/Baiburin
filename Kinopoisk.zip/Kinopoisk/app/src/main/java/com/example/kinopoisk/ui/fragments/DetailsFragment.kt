package com.example.kinopoisk.ui.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.navArgs
import com.example.kinopoisk.R
import com.example.kinopoisk.databinding.FragmentDetailsBinding
import com.example.kinopoisk.model.Movie
import com.example.kinopoisk.ui.bindImage
import com.example.kinopoisk.ui.setHtmlText
import com.example.kinopoisk.ui.viewmodel.MovieViewModel


class DetailsFragment : Fragment() {
    private val viewModel: MovieViewModel by viewModels()
    private val navigationArgs: DetailsFragmentArgs by navArgs()

    private var _binding: FragmentDetailsBinding? = null
    private val binding
        get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentDetailsBinding.inflate(inflater)
        viewModel.getMovieDetails(navigationArgs.id)

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel.movie.observe(this.viewLifecycleOwner) { movie ->
            bind(movie)
        }
    }

    private fun bind(movie: Movie) {
        binding.apply {
            picture.bindImage(movie.posterUrl)
            name.text = movie.nameRu
            about.text = movie.description

            genres.setHtmlText(
                getString(
                    R.string.genres,
                    movie.genres.joinToString { it }
                )
            )
            countries.setHtmlText(
                getString(
                    R.string.countries,
                    movie.countries.joinToString { it }
                )
            )
        }
    }
}