package com.example.kinopoisk.model

data class Movies (
    val movies: List<Movie>? = null
)

data class Movie (
    val filmId: Int?,
    val nameRu: String,
    val posterUrl: String,
    val posterUrlPreview: String,
    val description: String? = "",
    val countries: List<String>,
    val genres: List<String>,
    val year: Int,
    val favorites: Boolean = false
)