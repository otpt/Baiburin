package com.example.kinopoisk.network

import com.example.kinopoisk.model.Movie
import com.example.kinopoisk.model.Movies
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Path

interface APIInterface {
    @Headers("X-API-KEY: $KEY")
    @GET(MOVIES_PATH)
    suspend fun getMovies(): Movies

    @Headers("X-API-KEY: $KEY")
    @GET(MOVIE_PATH)
    suspend fun getMovie(@Path("id") id: Int): Movie

    private companion object {
        const val MOVIES_PATH = "api/v2.2/films/top/?type=TOP_100_POPULAR_FILMS"
        const val MOVIE_PATH = "api/v2.2/films/top/{id}"
        const val KEY = "e30ffed0-76ab-4dd6-b41f-4c9da2b2735b"
    }
}