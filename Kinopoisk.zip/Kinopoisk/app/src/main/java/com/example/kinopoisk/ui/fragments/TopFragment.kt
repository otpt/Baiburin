package com.example.kinopoisk.ui.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.example.kinopoisk.databinding.FragmentTopBinding
import com.example.kinopoisk.ui.adapter.FilmListAdapter
import com.example.kinopoisk.ui.viewmodel.MovieViewModel

class TopFragment : Fragment() {

    private val viewModel: MovieViewModel by viewModels()
    private var _binding: FragmentTopBinding? = null
    private val binding
        get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        _binding = FragmentTopBinding.inflate(inflater)
        binding.lifecycleOwner = this
        binding.viewModel = viewModel

        val adapter = FilmListAdapter {
            val action =
                it.filmId?.let { it1 ->
                    TopFragmentDirections.actionTopFragmentToDetailsFragment(
                        it1
                    )
                }
            if (action != null) {
                this.findNavController().navigate(action)
            }
        }

        binding.recyclerView.adapter = adapter

        return binding.root
    }
}
