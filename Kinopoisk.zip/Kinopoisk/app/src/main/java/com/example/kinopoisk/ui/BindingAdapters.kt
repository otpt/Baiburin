package com.example.kinopoisk.ui

import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.core.net.toUri
import androidx.core.text.HtmlCompat
import androidx.databinding.BindingAdapter
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.example.kinopoisk.R
import com.example.kinopoisk.model.Movie
import com.example.kinopoisk.ui.adapter.FilmListAdapter
import com.example.kinopoisk.ui.viewmodel.MovieViewModel
import com.example.kinopoisk.ui.viewmodel.MovieViewModel.Companion.ApiResult


@BindingAdapter("imageUrl")
fun ImageView.bindImage(imgUrl: String?) {
    imgUrl?.let {
        val imgUri = imgUrl.toUri().buildUpon().scheme("https").build()
        load(imgUri) {
            placeholder(R.drawable.loading_animation)
            error(R.drawable.ic_broken_image)
        }
    }
}

@BindingAdapter("listData")
fun bindRecyclerView(recyclerView: RecyclerView, data: List<Movie>?) {
    val adapter = recyclerView.adapter as FilmListAdapter
    adapter.submitList(data)
}


@BindingAdapter("filmApiStatus")
fun bindStatus(statusImageView: ImageView, status: ApiResult) {
    when (status) {
        ApiResult.PROGRESS -> {
            statusImageView.visibility = View.VISIBLE
            statusImageView.setImageResource(R.drawable.loading_animation)
        }
        ApiResult.ERROR -> {
            statusImageView.visibility = View.VISIBLE
            statusImageView.setImageResource(R.drawable.ic_connection_error)
        }
        ApiResult.SUCCESS -> {
            statusImageView.visibility = View.GONE
        }
    }
}

@BindingAdapter("filmApiStatus")
fun bindStatus(statusTextView: TextView, status: MovieViewModel.Companion.ApiResult) {
    when (status) {
        ApiResult.ERROR -> {
            statusTextView.visibility = View.VISIBLE
        }
        else -> {
            statusTextView.visibility = View.GONE
        }
    }
}

@BindingAdapter("goneUnless")
fun goneUnless(view: View, visible: Boolean) {
    view.visibility = if (visible) View.VISIBLE else View.GONE
}

@BindingAdapter(value = ["htmlText"])
fun TextView.setHtmlText(string: String?) {
    text =
        if (string == null) "" else HtmlCompat.fromHtml(string, HtmlCompat.FROM_HTML_MODE_COMPACT)
}