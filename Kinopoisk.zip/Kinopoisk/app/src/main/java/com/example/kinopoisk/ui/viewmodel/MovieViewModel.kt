package com.example.kinopoisk.ui.viewmodel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.kinopoisk.model.Movie
import com.example.kinopoisk.model.Movies
import com.example.kinopoisk.network.Api
import kotlinx.coroutines.launch

class MovieViewModel : ViewModel() {

    private val _result = MutableLiveData<ApiResult>()
    private val _movies = MutableLiveData<Movies>()
    private val _movie = MutableLiveData<Movie>()
    val result: LiveData<ApiResult>
        get() = _result
    val films: LiveData<Movies> = _movies
    val movie: LiveData<Movie>
        get() = _movie

    fun getMovies() {
        viewModelScope.launch {
            _result.value = ApiResult.PROGRESS
            try {
                _movies.value = Api.retrofitService.getMovies()
                _result.value = ApiResult.SUCCESS
            } catch (e: Exception) {
                _result.value = ApiResult.ERROR
                _movies.value = Movies()
                Log.e(TAG, e.toString())
            }
        }
    }

    fun getMovieDetails(id: Int) {
        viewModelScope.launch {
            _result.value = ApiResult.PROGRESS
            try {
                _movie.value = Api.retrofitService.getMovie(id)
                _result.value = ApiResult.SUCCESS
            } catch (e: Exception) {
                _result.value = ApiResult.ERROR
                Log.e(TAG, e.toString())
            }
        }
    }

    init {
        getMovies()
    }

    companion object {
        enum class ApiResult { PROGRESS, ERROR, SUCCESS }
        const val TAG = "MOVIES"
    }
}
